Change all Sruthy's name to yours.Similarly guide's name, designation etc in Mythesis.tex and thesis.cls(Ln:75 change hspace accordingly as per ur name's size in Mythesis.tex)
(Hint search "Sruthy" and "Priya" and change)
Change title and author and guide in Mythesis.tex
Write abstract,ack,dedication  in Mythesis.tex
In thesis.cls(Ln 1123)change only the designation of the guide.

